#!/bin/bash      
#title           :
#description     :
#author		     :Mithun Reddy Lacchannagari
#date            :08112012
#version         :1.0    
#usage		     :
#CopyRights      : Mithun Technologies
#Contact         :9980923226
echo "Hello Guys"
echo "Welcome to ShellScript"
echo "This is the first shell script example !!"


