#!/bin/bash      
#title           :
#description     :
#author		     :Mithun Reddy L
#date            :08112012
#version         :1.0    
#usage		     :

name="Mithun Reddy L"
id=08112012

echo "The name varibale value is: "$name
echo "The id variable value is: "$id


