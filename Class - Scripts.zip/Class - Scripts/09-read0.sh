#!/bin/bash      
#title           :
#description     :
#author		     :Mithun Reddy L
#date            :08112012
#version         :1.0    
#usage		     :

echo "Please enter your name"
read name

echo "The name you entered is: " $name
