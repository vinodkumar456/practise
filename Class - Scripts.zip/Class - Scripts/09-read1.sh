#!/bin/bash      
#title           :
#description     :
#author		     :Mithun Reddy Lacchannagari
#date            :08112012
#version         :1.0    
#usage		     :

echo "Please enter the DevOps Tools: "

read devOpsTool1 devOpsTool2 devOpsTool3 devOpsTool4 devOpsTool5

echo The DevOps Tools/Techniques you entered are $devOpsTool1   $devOpsTool2   $devOpsTool3   $devOpsTool4 $devOpsTool5