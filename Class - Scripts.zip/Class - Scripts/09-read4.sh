#!/bin/bash      
#title           :
#description     :
#author		     :Mithun Reddy L
#date            :08112012
#version         :1.0    
#usage		     :

echo "Please enter DevOps tools name"
read 

echo "The tools ypu entered are" $REPLY
