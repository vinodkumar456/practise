#!/bin/bash      
#title           :
#description     :
#author		     :Mithun Reddy Lacchannagari
#date            :08112012
#version         :1.0    
#usage		     :

echo "Can you see the following output!!!"
echo "For loop demo started"  
for (( i=1; i<=5; i++ ))
do
   echo $i
   echo ""
done
echo "For loop demo over" 

