#!/bin/bash      
#title           :
#description     :
#author		     :Mithun Reddy Lacchannagari
#date            :08112012
#version         :1.0    
#usage		     :


echo "Enter the 2 numbers"
read numb1 numb2

echo The addition of 2 numbers is : $numb1 + $numb2

