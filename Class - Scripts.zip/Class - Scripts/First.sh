#First.sh
#--------
echo "First Shell script"
fun1(){
echo "First Function"
}

fun2(){
echo "Second Function"
}