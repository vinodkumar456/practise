#Second.sh
#---------
source ./first.sh
fun1
fun2
